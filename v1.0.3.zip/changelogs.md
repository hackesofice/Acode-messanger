## Version 1.0.1
- Resolved `File not Found error`

### Version 1.0.0
- Initial release
- Real-time messaging
- User authentication
- Profile management
- Modern UI design