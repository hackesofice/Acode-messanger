
### Version 1.0.0
- Initial release
- Real-time messaging
- User authentication
- Profile management
- Modern UI design