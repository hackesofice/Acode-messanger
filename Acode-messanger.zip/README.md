# Desclaimer

> warning its a useless browser and you might going to waste your money.

This is a kind of mini browser, A Developer needs to surf over internet to gethare information, for now theres no easy way to surf in the acode app so we created this as an solution. we are working to make it more and more capeble

> Warning !
> for now its not much usefull work is still in progress soon well provide a major update of it



# installation steps

`step 1` install the Acode app form play store.

`step 2` tap on menu icon avilable on the uooer left corner.

`step 3` tap on _extension_ icon.

`steo 4` type _Brouser_ on the search baar.

`step 5` tap on the result ( The Plugin you're seeing ).

`step 6` tap on _install_ button 

# how to use

`step 1` tap on menu icon avilable on the uooer left corner.

`step 2` Now you'll see new Brouser icon on the top right corner tap on it to access.

`step 3` The mini app will be opend on the sidebar

`note`
> The plugin is under heavy / active Developement phrase and may be sometimes you'll face some errors and featurs may not work as expected but we are trying to improve it and soon it will be in its 100% working phrase
# Different tabs amd buttons

*search bar*
youll see a searcg bar on the top you can type your query or entire url on it

*Go Button*
after typing url you'll need to tap on this button to see the search result.

*Quick access bar*
this is a horizontal bar where youll find recently used tools and if you wanna open any of them again then just tap on it and it will quickly open on the main screen.

*main screen*
this is described on the last of the page

*all Apps bars*
now at last youll see Two vertical bars hear youll find all avilable quick apps and we will expend it in future


# main screen

this is a main screen where youll see -

*left button*
To go back to previous page just tap on it

*right button*
if you wanna go to the next page again just tap on it and it will take you to the next page

*full screen button*
if you tap on  it then your current page will be opend on big screen and youll able to access this brouser on a big screen

*X icon*
If you tap on this icon your any opend any page will be closed and youll see a default page



`note`
> if you have any concerns about it plese open a issue on github page we will do our best to resolve the issue

# Contributions

the plugin is open source everythig is open and we welcome any kind of contributions, make sure proper information is provided in push request
